/*
programmer:
Cal Barkman
Class:
CST 420
Assignment:
Assignment 2
Due date:
7/20/14
*/


#include "book.h"
#include <iostream>
using std::cout;
using std::endl;

#define DEBUGGING 0

/*
right now it prints with a word number instead of a line number
need to figure out how to change that value and clean up the constructor then I am finished.
*/

void main()
{
	book c;
	c.print();
	return;
}