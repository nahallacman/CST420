#ifndef BOOK_H
#define BOOK_H
#include "word.h"
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
#include <list>
#include <algorithm>

using std::istream_iterator;
using std::multiset;
using std::list;

typedef  istream_iterator<string>  StringInIter;

class book
{
public:
	book();
	void print();
	void print_word(string _search);

private:

	string book::normalize_word(string _normalize);
	string m_filename_book;
	string m_filename_skiplist;
	list<string> m_skiplist;
	multiset<word> m_storage;


};

#endif