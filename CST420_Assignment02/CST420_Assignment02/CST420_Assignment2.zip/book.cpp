#include "book.h"

using std::ifstream;
using std::cout;
using std::endl;
using std::for_each;

#define DEBUGGING 0

book::book()
{
	int current_page = 1;
	int current_word = 1;
	m_filename_book = "doc.txt";
	m_filename_skiplist = "skip.txt";

#if DEBUGGING
	cout << "Running in debug mode." << endl;
	cout << "m_filename_book = " << m_filename_book;
	cout << "m_filename_skiplist = " << m_filename_skiplist;
	string test = "TeSt";
	cout << "Testing 1: " << test << endl;
	normalize_word(test);
	cout << "Testing 2: " << test << endl;
	test = "test.";
	normalize_word(test);
	cout << "Testing 3: " << test << endl;
#else
	cout << "Not running in debug mode." << endl;
#endif

	ifstream inSkip(m_filename_skiplist); // initalize skip list

	if (inSkip.is_open())
	{
		#if DEBUGGING
		cout << "Skip File open" << endl;
		#endif
		StringInIter SkipIter(inSkip);
		for (; SkipIter != StringInIter(); ++SkipIter)
		{
			string insert = *SkipIter;
			normalize_word(insert);
			m_skiplist.push_back(insert);
		}
	}
	else
	{
		#if DEBUGGING
		cout << "Skip File not open" << endl;
		#endif
	}

	ifstream  inFile(m_filename_book); // initalize doc

	if (inFile.is_open())
	{
#if DEBUGGING
		cout << "File open" << endl;
#endif
		StringInIter InIter(inFile);
		for (; InIter != StringInIter(); ++InIter, ++current_word)
		{
			string checking(*InIter);
			if (*InIter == "<newpage>")
			{
				current_page++;
				current_word = 1;
			}
			else
			{
				checking = normalize_word(checking);
				bool in_list = false;
				for (auto iter = m_skiplist.begin(); iter != m_skiplist.end(); iter++) //iterate through skip list to see if the word is in the skip list
				{
					if (*iter == checking)
					{
						//word is in skip list
						in_list = true;
					}
					else
					{
						//word in not in skip list
						//in_list = false;
					}
				}
				if (in_list == false)
				{
					string insert = *InIter;
					word a(normalize_word(insert), current_page, current_word);
					m_storage.insert(a);
				}
			}
		}
	}
	else
	{
#if DEBUGGING
		cout << "File not open" << endl;
#endif
	}
}

void normalize_char(char &i) {  // function:
	i = tolower(i);
}

bool myispunct(char i)
{
	if (ispunct(i) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
/*
void book::normalize_word(string& _normalize)
*/
string book::normalize_word(string _normalize)
{
#if DEBUGGING
	cout << "begin lower case modification: " << _normalize << endl;
#endif
	//change the whole string to lower case
	for_each(_normalize.begin(), _normalize.end(), normalize_char);
	//then remove anything that isn't a character
#if DEBUGGING
	cout << "end lower case modification: " << _normalize << endl;
	cout << "Begin punctuation removal: " << _normalize << endl;
#endif
	string result;
	std::remove_copy_if(_normalize.begin(), _normalize.end(),
		std::back_inserter(result),         
		ispunct
		);
#if DEBUGGING
	cout << "End punctuation removal: " << result << endl;
#endif
	return result;
}

/*
I built this without looking at the requirements. It isn't used for anything, but it was well built so I decided it would be a shame to delete it.
*/
void book::print_word(string _search)
{
#if DEBUGGING
	cout << "Beginning print" << endl
		<< "looking for the word: " << _search << endl;
#endif
	word test(_search, 1, 1);
	std::pair <std::multiset<word>::iterator, std::multiset<word>::iterator> ret;
	ret = m_storage.equal_range(test);
	if (ret.first->getword() == ret.second->getword())
	{
#if DEBUGGING
		cout << "Word not found." << endl;
#endif
	}
	else
	{
#if DEBUGGING
		cout << "Word found." << endl;
#endif
		cout << _search << endl;
	}
	for (std::multiset<word>::iterator it = ret.first; it != ret.second; ++it)
	{
		cout << "  " << it->getpagenum() << '.' << it->getwordnum() << endl;
	}
#if DEBUGGING
	cout << "Ending print" << endl;
#endif
}

void book::print()
{
	string last;
	for (std::multiset<word>::iterator it = m_storage.begin(); it != m_storage.end(); ++it)
	{
		if (last != it->getword())
		{
			
			cout << endl << it->getword() << endl
				<< "  " << it->getpagenum() << "." << it->getwordnum();
		}
		else
		{
			cout << ", " << it->getpagenum() << "." << it->getwordnum();
		}
		last = it->getword();
	}
}